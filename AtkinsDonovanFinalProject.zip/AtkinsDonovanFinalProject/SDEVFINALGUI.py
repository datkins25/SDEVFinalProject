'''
Donovan Atkins
SDEV Final Project
EZOrder
'''

import tkinter as tk
from tkinter import messagebox
from tkinter import *
from PIL import ImageTk, Image

class Product:
    def __init__(self, name, price):
        self.name = name
        self.price = price

class EZOrder(tk.Frame):
    
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        self.master.title("EZOrder")
        self.products = []
        self.grid()
        self.total_price = 0.00
        self.cart = []
        
        # part of pictures
        self.burger = ImageTk.PhotoImage(Image.open("donivunburgv2.png"))
        self.taco = ImageTk.PhotoImage(Image.open("metaco.png"))
        self.pizza = ImageTk.PhotoImage(Image.open("pizza.png"))

        # Create product objects
        self.products.append(Product("Burger", 9.99))
        self.products.append(Product("Taco", 7.99))
        self.products.append(Product("Pizza", 12.99))
                
        # name
        self.shop_label = tk.Label(master, text = "EZOrder", font=("Comic Sans MS", 24))
        
        # Buttons and pictures
        self.burger_button = tk.Button(self, image=self.burger, command=lambda:self.add_to_cart("Burger"))
        self.burger_button.config(height=500, width=475)
        self.taco_button = tk.Button(self, image=self.taco, command=lambda:self.add_to_cart("Taco"))
        self.taco_button.config(height=500, width=475)
        self.pizza_button = tk.Button(self, image=self.pizza, command=lambda:self.add_to_cart("Pizza"))
        self.pizza_button.config(height=500, width=475)
        self.burger_label = tk.Label(self, text="Burger")
        self.taco_label = tk.Label(self, text="Taco")
        self.pizza_label = tk.Label(self, text="Pizza")
        
        self.burger_button.grid(row=1, column=0)
        self.taco_button.grid(row=1, column=1)
        self.pizza_button.grid(row=1, column=2)
        self.burger_label.grid(row=2, column=0)
        self.taco_label.grid(row=2, column=1)
        self.pizza_label.grid(row=2, column=2)
        
        # Menu bar
        self.menu_bar = tk.Menu(master)
        self.total = tk.Menu(master)
        self.quit = tk.Menu(master)
        self.about_menu = tk.Menu(self.menu_bar, tearoff=0)
        self.total = tk.Menu(self.menu_bar, tearoff=0)
        self.quit = tk.Menu(self.menu_bar, tearoff=0)
        self.about_menu.add_command(label="Ingredients", command=self.show_ingreds)
        self.about_menu.add_command(label="Contact Information", command=self.show_contact)
        self.total.add_command(label="Total", command=self.open_second_window)
        self.quit.add_command(label="Confirm Quit", command=self.master.quit)
        
        # bar at top
        self.menu_bar.add_cascade(label="About", menu=self.about_menu)
        master.config(menu=self.menu_bar)
        self.menu_bar.add_cascade(label="Bill", menu=self.total)
        master.config(menu=self.menu_bar)
        self.menu_bar.add_cascade(label="QUIT", menu=self.quit)
        
        # products and checkout window
        self.product_label = tk.Label(self.master, text="Products:")

        self.product_listbox = tk.Listbox(self.master)

        for product in self.products:
            self.product_listbox.insert(tk.END, f"{product.name} - ${product.price:.2f}")

        self.add_button = tk.Button(self.master, text="Add to cart", command=self.add_to_cart)

        self.total_label = tk.Label(self.master, text="Total: ${total:.2f}")

        self.total_value_label = tk.Label(self.master, text="$0.00")

        self.checkout_button = tk.Button(self.master, text="Checkout", command=self.checkout)

        self.back_button = tk.Button(self.master, text="Back to Ordering Screen", command=self.back_to_ordering_screen)


    def checkout(self):
        total = 0
        for item in self.cart:
            total += item.price

        messagebox.showinfo("Checkout", f"Total price: ${total:.2f}")
        self.cart = []
        self.cart_listbox.delete(0, tk.END)

    def add_to_cart(self, product=None):
        if product is None:
            selected_index = self.product_listbox.curselection()
        if not selected_index:
            return
        product_name = self.product_listbox.get(selected_index)
        product = self.get_product_by_name(product_name.split(" - ")[0])
    
        self.cart.append(product)
        self.total_price += product.price
        self.total_price_label.config(text=f"Total Price: ${self.total_price:.2f}")

        if not self.cart_listbox:
            self.cart_listbox = tk.Listbox(self.master)
            self.cart_listbox.pack(side=tk.RIGHT, fill=tk.BOTH)

        self.cart_listbox.insert(tk.END, f"{product.name} - ${product.price:.2f}")

    def back_to_ordering_screen(self):
        self.total_price = 0.00
        self.cart = []
        self.cart_listbox.delete(0, tk.END)
        self.total_price_label.config(text=f"Total Price: ${self.total_price:.2f}")
        self.back_button.pack_forget() # Remove the button from the screen

    # Hours
    def show_ingreds(self):
        ingreds_lines = ['Pepperoni Pizza: Flour dough, tomato pizza sauce, pepperoni, mozzarella cheese, ground black pepper, and fresh oregano.', 'Taco: Ground beef, cheese, onion, tomato, chili peppers, corn taco shells, and taco seasoning.', 'Burger: ground beef patty, flour bun, cheese, tomato, onion, ketchup, mustard, pickle.']
        messagebox.showinfo('Ingredients', "\n".join(ingreds_lines))

    # Contact info
    def show_contact(self):
        contact_lines = ['Address: 123 ICanCount Street.', 'Phone: 555-555-5555', 'Email: info@donovanface.com']
        messagebox.showinfo('Contact Info', "\n".join(contact_lines))



    def open_second_window(self):
        messagebox.showinfo('Total', f'Total value: ${self.total_price:.2f}')

    # Create the cart listbox
        cart_listbox = Listbox(self.second_window, width=50)

    # Display the selected products in the cart
        for product in self.products:
            cart_listbox.insert(END, f"{product['name']} - ${product['price']}")

    # Create the total value label
        total_label = Label(self.second_window, text=f"Total value: ${self.total_price}")

    def cart_listbox(self):    
        cart_listbox = Listbox(self.second_window, width=50)

    # open total window
def opentotalWindow(self):
        newtotaleWindow = Toplevel(self)
        self.totalWindow.title("Total")

    # total/payment
def show_total(self):
        btn = Button(self,
                     text = "Total",
                     command = opentotalWindow)
        btn.pack(pady=10)

class GUI:

    def __init__(self, master):
        self.master = master
        master.title("Shopping Cart")

        # Define product list
        self.product_list = [
            Product("Burger", 9.99),
            Product("Taco", 7.99),
            Product("Pizza", 12.99),
        ]

        # Create listbox to display products
        self.product_listbox = Listbox(master)
        for product in self.product_list:
            self.product_listbox.insert(END, product.name)

        # Create button to add selected product to cart
        self.add_to_cart_button = Button(master, text="Add to Cart", command=self.add_to_cart)

        # Create listbox to display cart items
        self.cart_listbox = Listbox(master)

        # Create label to display total price
        self.total_price_label = Label(master, text="")

    def add_to_cart(self):
        # Get selected product from product listbox
        selected_index = self.product_listbox.curselection()
        if selected_index:
            product = self.product_list[selected_index[0]]
            self.cart_listbox.insert(END, product.name)
            self.total_price += product.price
            self.total_price_label.configure(text="Total Price: $%.2f" % self.total_price)
        else:
            messagebox.showerror("Error", "Please select a product to add to cart.")

root = tk.Tk()
app = EZOrder(master=root)
my_gui = GUI(root)
app.mainloop()
root.mainloop()