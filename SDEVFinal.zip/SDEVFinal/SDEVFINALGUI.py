'''
Donovan Atkins
SDEV Final Project
EZOrder
'''

import tkinter as tk
from tkinter import messagebox
from PIL import ImageTk, Image
from tkinter import *


class EZOrder:

    def __init__(self,master):
        self.master = master
        master.title("EZOrder")
        
        # background image
        root.geometry("400x400")
        bg = PhotoImage(file = "bgimg.png")
        canvas1 = Canvas( root, width = 400,
                 height = 400)
        canvas1.pack(fill = "both", expand = True)
        canvas1.create_image( 0, 0, image = bg, 
                     anchor = "nw")
        root.mainloop()

        # image
        self.img = Image.open("donivunburg.png") 
        self.img = self.img.resize((500, 500), Image.ANTIALIAS)
        self.photo = ImageTk.PhotoImage(self.img)

        # image display
        self.label = tk.Label(master, image = self.photo)
        self.label.pack()
        
        # name
        self.shop_label = tk.Label(master, text = "EZOrder", font=("Comic Sans MS", 24))
        self.shop_label.pack()
        
        self.burger_button = tk.Button(master, text="Burger", image="donivunburg.png", compound=TOP, command=self.order_burger)
        self.burger_button.pack()

        

        self.menu_bar = tk.Menu(master)
        self.about_menu = tk.Menu(self.menu_bar, tearoff=0)
        self.about_menu.add_command(label="Ingredients", command=self.show_hours)
        self.about_menu.add_command(label="Contact Information", command=self.show_contact)
        
        self.menu_bar.add_cascade(label="About", menu=self.about_menu)
        master.config(menu=self.menu_bar)

        

    # Order Food
    def order_fburger(self):
        messagebox.showinfo("Ordered Burger", "Thank you for your order, it is on the way!")

    # Hours
    def show_hours(self):
        messagebox.showinfo("Ingredients", "Pepperoni Pizza: Flour dough, tomato pizza sauce, pepperoni, mozzarella cheese, ground black pepper, and fresh oregano.\nTaco: Ground beef, cheese, onion, tomato, chili peppers, corn taco shells, and taco seasoning.\nBurger: ground beef patty, flour bun, cheese, tomato, onion, ketchup, mustard, pickle.")

    # Contact info
    def show_contact(self):
        messagebox.showinfo("Contact Info", "Address: 123 ICanCount Street.\nPhone: 555-555-5555\nEmail: info@donovanface.com")



root = tk.Tk()
app = EZOrder(root)
root.mainloop()